# Navigate

[Article](https://kavita-ganesan.com/comparison-between-cbow-skipgram-subword)
