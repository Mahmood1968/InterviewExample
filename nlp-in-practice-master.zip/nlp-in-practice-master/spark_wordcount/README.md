# Word Count and Reading CSV & JSON files with PySpark

- [Article](http://kavita-ganesan.com/reading-csv-and-json-files-in-spark/)
- [Script](scripts/)
