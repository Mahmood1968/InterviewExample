# Navigate
- [Text Preprocessing Notebook](Text%20Preprocessing%20Examples.ipynb)
- [Text preprocesing article](http://kavita-ganesan.com/getting-started-with-text-preprocessing/#.XHa4-ZNKhuU)


# Running the Text Preprocessing Tutorial Notebook

1. From the command line, first, clone this repo.
```
git clone <this repo url>
```

2. Next, switch to the text preprocessing directory of this repo.
```
cd  nlp-in-practice/text-pre-processing
```

3. Then, run jupyter notebook
```
jupyter notebook
```
4. Select `Text Preprocessing Examples.ipynb`, now you can re-run the cells and re-use the code!
